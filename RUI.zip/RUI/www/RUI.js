var function_obj_array = []
var drag_start_x = null
var drag_start_y = null
var drag_start_translate_x = null
var drag_start_translate_y = null




Shiny.addCustomMessageHandler('addSVG',function(message){
	d3.select("#body").append('svg')
	 .attr('id','mainSVG')
	 .attr('height',"1000px")
	 .attr('width','100%')


})

Shiny.addCustomMessageHandler('addFunctionObj',function(message){
	
	id = message.package + '__' + message.function_name + '__group'
	d3.select('#mainSVG').append('g')
	.attr('id',id)
	.attr('transform','translate(0,0)')
	.call(d3.drag()
    	.on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended));

	d3.select('#' + id).append('rect')
	.attr('id', id + '_rect')
	.attr('height',100)
	.attr('width',100)
	.attr('fill',function() {
    return "hsl(" + Math.random() * 360 + ",100%,50%)";
    })
    .text(message.function_name);
    

    d3.select('#' + id).append('text')
    .attr('id',id + '_text')
    .text(message.function_name)
    .attr('class','functionText')
    .attr('x',d3.select('#' + id + '_rect').attr('width')/2)
    .attr('y',d3.select('#' + id + '_rect').attr('height')/2);

    
})

function dragstarted(d) {
  drag_start_x = d3.event.x  
  drag_start_y = d3.event.y 
  drag_start_translate_x = d3.select(this)._groups[0][0].transform.animVal[0].matrix.e
  drag_start_translate_y = d3.select(this)._groups[0][0].transform.animVal[0].matrix.f
  d3.select(this).attr('stroke','#000').attr('stroke-width','2px');
}

function dragged(d) {
  x_change = d3.event.x - drag_start_x
  y_change = d3.event.y - drag_start_y
  d3.select(this).attr("transform", "translate("+(drag_start_translate_x + x_change)+","+ (drag_start_translate_y + y_change)+")");
}

function dragended(d) {
  d3.select(this).attr('stroke','#fff').attr('stroke-width','1px');
}