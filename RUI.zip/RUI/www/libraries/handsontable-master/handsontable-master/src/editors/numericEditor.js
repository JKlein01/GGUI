import TextEditor from './textEditor';

/**
 * @private
 * @editor NumericEditor
 * @class NumericEditor
 */
class NumericEditor extends TextEditor {}

export default NumericEditor;
