/* eslint-disable import/prefer-default-export */

import deCH from './de-CH';
import deDE from './de-DE';
import enUS from './en-US';
import jaJP from './ja-JP';
import plPL from './pl-PL';
import ptBR from './pt-BR';
import ruRU from './ru-RU';

export {
  deCH,
  deDE,
  enUS,
  jaJP,
  plPL,
  ptBR,
  ruRU
};
