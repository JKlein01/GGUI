library(shiny)

# Define UI for application that draws a histogram
ui <- fluidPage(id = "body",
   
   # Application title
   titlePanel("RUI"),
   includeHTML('www/RUI.html'),
   
   # Sidebar with a slider input for number of bins 
   sidebarLayout(
      sidebarPanel(
         selectizeInput(inputId = "selectFunctions",label = "Select Functions to Add",choices = unlisted_functions, multiple= T),
         actionButton(inputId = "addFunctions", "Add Functions")
      ),
      
      # Show a plot of the generated distribution
      mainPanel(id = "main", height = "1000px"
         
      )
   )
)

# Define server logic required to draw a histogram
server <- function(input, output, session) {
   function_list = list()
   output_list = list()
   session$sendCustomMessage('addSVG',message = 1)
   
   observeEvent(input$addFunctions,{
     for(i in input$selectFunctions){
       id = paste(i,rnorm(1),sep = "_")
       package = strsplit(i,"::")[[1]][1]
       function_name = strsplit(i,"::")[[1]][2]
       function_list[[id]]$potential_args = do.call(what = "getHelpList",args = list(package = package, topic = function_name))$arguments
       session$sendCustomMessage('addFunctionObj',message = list(fullName = i,id = id, package = package, function_name = function_name))
     }
   }
   )
}

# Run the application 
shinyApp(ui = ui, server = server)

